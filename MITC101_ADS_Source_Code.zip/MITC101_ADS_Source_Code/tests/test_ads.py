import unittest, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from task1.task1 import remove_duplicates, merge_sort, quick_sort, randomized_select
from task2.task2 import Stack, CircularQueue, DoublyLinkedList, UndoRedo
from task3.task3 import BST, ChainedHash, LinearProbingHash, RedBlackTree, next_prime
from task4.task4 import bottom_up, greedy, floyd_warshall
class TestADS(unittest.TestCase):
    def test_task1(self):
        x=[3,1,2,1];self.assertEqual(remove_duplicates(x),[3,1,2])
        self.assertEqual(merge_sort(x),[1,1,2,3]);self.assertEqual(quick_sort(x),[1,1,2,3])
        self.assertEqual(randomized_select(x,2),2)
    def test_stack_queue(self):
        s=Stack();s.push(3);self.assertEqual(s.peek(),3);self.assertEqual(s.pop(),3);self.assertTrue(s.isEmpty())
        q=CircularQueue(2);q.enqueue(1);q.enqueue(2);self.assertEqual(q.dequeue(),1);q.enqueue(3);self.assertEqual(q.contents(),[2,3])
    def test_linked_list_undo(self):
        ll=DoublyLinkedList();ll.insert_tail("a");ll.insert_tail("b");ll.insert_after("a","x")
        self.assertEqual(ll.forward(),["a","x","b"]);ll.reverse();self.assertEqual(ll.backward(),["a","x","b"]);self.assertFalse(ll.has_cycle())
        u=UndoRedo();u.apply("A");u.apply("B");self.assertTrue(u.undo());self.assertEqual(u.state,["A"]);self.assertTrue(u.redo())
    def test_hash_bst_rb(self):
        m=next_prime(100);h=ChainedHash(m);h.insert("SC0000000001");self.assertTrue(h.search("SC0000000001")[0])
        op=LinearProbingHash(m);op.insert("SC0000000001");self.assertTrue(op.search("SC0000000001")[0])
        b=BST();[b.insert(x) for x in [2,1,3]];b.delete(2);self.assertEqual(b.inorder(),[1,3])
        rb=RedBlackTree()
        for x in ["Abad","Bautista","Cruz","Dela Cruz","Espiritu","Flores","Garcia","Hernandez","Ilagan","Jimenez"]:rb.insert(x)
        self.assertEqual(rb.root.color,"BLACK");self.assertEqual([x for x,c in rb.inorder()],sorted(["Abad","Bautista","Cruz","Dela Cruz","Espiritu","Flores","Garcia","Hernandez","Ilagan","Jimenez"]))
    def test_knapsack_routes(self):
        val,chosen,dp=bottom_up(29);self.assertEqual(val,2320)
        d,snaps,path=floyd_warshall();self.assertEqual(d[0][4],17);self.assertEqual(path,["Manila","Cebu","Davao"])
if __name__=="__main__":unittest.main(verbosity=2)
